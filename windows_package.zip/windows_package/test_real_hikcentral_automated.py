#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
HIKCENTRAL AUTOMATION - VERSÃO 100% AUTOMÁTICA
Baseado nos seletores capturados do modo step-by-step
"""

import time
import os
import sys
import json
import argparse
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.options import Options

def load_visitor_data(file_path=None, visitor_id=None):
    """Carrega dados do visitante de arquivo ou usa dados padrão"""
    if file_path and os.path.exists(file_path):
        try:
            with open(file_path, 'r') as f:
                data = json.load(f)
            print(f"✅ Dados carregados do arquivo: {file_path}")
            return data
        except Exception as e:
            print(f"⚠️ Erro ao carregar arquivo {file_path}: {e}")
    
    # Dados padrão para teste
    default_data = {
        'name': f'Visitante Teste {visitor_id or "Default"}',
        'phone': '11987654321',
        'rg': '87654321',
        'placa': 'XYZ9876'
    }
    print(f"✅ Usando dados padrão: {default_data['name']}")
    return default_data

def fill_field_with_tab(driver, field, value, field_name):
    """Preenche um campo e navega com TAB"""
    try:
        field.clear()
        for char in value:
            field.send_keys(char)
            time.sleep(0.1)
        time.sleep(1)
        field.send_keys(Keys.TAB)
        print(f"✅ {field_name} preenchido: '{value}'")
        time.sleep(1)
    except Exception as e:
        print(f"⚠️ Erro ao preencher {field_name}: {e}")

def select_dropdown_option(driver, field_selector, option_text, field_name):
    """Seleciona opção em dropdown usando seletores capturados"""
    try:
        # Clicar no campo para abrir dropdown
        field = driver.find_element("css selector", field_selector)
        field.click()
        print(f"✅ Campo {field_name} clicado para abrir dropdown")
        time.sleep(2)
        
        # Selecionar a opção específica
        option = driver.find_element("xpath", f"//span[contains(text(), '{option_text}')]")
        option.click()
        print(f"✅ Opção '{option_text}' selecionada para {field_name}")
        time.sleep(2)
        
        # Verificar se foi selecionado
        field_value = field.get_attribute("value")
        if option_text in field_value:
            print(f"✅ {field_name} confirmado: {field_value}")
        else:
            print(f"⚠️ {field_name} não foi atualizado corretamente")
            
    except Exception as e:
        print(f"⚠️ Erro ao selecionar {field_name}: {e}")

def upload_photo_to_hikcentral(driver, photo_path):
    """
    Faz upload da foto do visitante no HikCentral
    
    Args:
        driver: WebDriver do Selenium
        photo_path: Caminho para arquivo da foto
    
    Returns:
        bool: True se upload foi bem-sucedido
    """
    try:
        if not photo_path or not os.path.exists(photo_path):
            print("⚠️ Nenhuma foto disponível para upload")
            return False
        
        print(f"📸 Fazendo upload da foto: {photo_path}")
        
        # Procurar pelo campo de upload de foto
        # Estratégia 1: Procurar por input type="file"
        try:
            photo_input = driver.find_element("css selector", "input[type='file']")
            if photo_input and photo_input.is_displayed():
                photo_input.send_keys(photo_path)
                print("✅ Foto enviada via input file direto")
                time.sleep(3)  # Aguardar upload processar
                return True
        except Exception as e:
            print(f"⚠️ Input file direto não funcionou: {e}")
        
        # Estratégia 2: Procurar por botão de upload
        try:
            upload_buttons = driver.find_elements("xpath", "//button[contains(text(), 'Carregar') or contains(text(), 'Upload') or contains(text(), 'Escolher')]")
            if upload_buttons:
                for btn in upload_buttons:
                    if btn.is_displayed():
                        btn.click()
                        print("✅ Botão de upload clicado")
                        time.sleep(1)
                        
                        # Procurar input file que pode ter aparecido
                        hidden_inputs = driver.find_elements("css selector", "input[type='file']")
                        for inp in hidden_inputs:
                            try:
                                inp.send_keys(photo_path)
                                print("✅ Foto enviada via input file oculto")
                                time.sleep(3)
                                return True
                            except:
                                continue
        except Exception as e:
            print(f"⚠️ Botão de upload não funcionou: {e}")
        
        # Estratégia 3: Procurar por área de drag & drop
        try:
            drop_areas = driver.find_elements("xpath", "//*[contains(@class, 'upload') or contains(@class, 'drop')]")
            if drop_areas:
                print("⚠️ Área de drag & drop encontrada, mas upload direto não suportado")
                # Em modo headless, drag & drop é complexo, então tentamos JS
                try:
                    # Tentar trigger de upload via JavaScript
                    driver.execute_script("""
                        var fileInput = document.querySelector('input[type="file"]');
                        if (fileInput) {
                            fileInput.style.display = 'block';
                            fileInput.style.visibility = 'visible';
                        }
                    """)
                    
                    photo_input = driver.find_element("css selector", "input[type='file']")
                    photo_input.send_keys(photo_path)
                    print("✅ Foto enviada via JavaScript workaround")
                    time.sleep(3)
                    return True
                except:
                    pass
        except Exception as e:
            print(f"⚠️ Área de drag & drop não funcionou: {e}")
        
        # Estratégia 4: Procurar na aba "Informação de Identidade"
        try:
            # Navegar para aba correta se necessário
            identity_tab = driver.find_element("xpath", "//div[contains(text(), 'Informação de identidade') or contains(text(), 'Identity')]")
            identity_tab.click()
            print("✅ Navegado para aba 'Informação de identidade'")
            time.sleep(2)
            
            # Procurar novamente por campos de upload
            photo_inputs = driver.find_elements("css selector", "input[type='file']")
            for inp in photo_inputs:
                if inp.is_displayed() or True:  # Tentar mesmo se não visível
                    try:
                        inp.send_keys(photo_path)
                        print("✅ Foto enviada na aba de identidade")
                        time.sleep(3)
                        return True
                    except:
                        continue
                        
        except Exception as e:
            print(f"⚠️ Aba de identidade não funcionou: {e}")
        
        print("⚠️ Não foi possível fazer upload da foto - todos os métodos falharam")
        return False
        
    except Exception as e:
        print(f"❌ Erro geral no upload da foto: {e}")
        return False

def main():
    # Parsear argumentos de linha de comando
    parser = argparse.ArgumentParser(description='HikCentral Automation Script')
    parser.add_argument('--visitor-data', help='Caminho para arquivo JSON com dados do visitante')
    parser.add_argument('--visitor-id', help='ID do visitante')
    parser.add_argument('--headless', action='store_true', help='Executar em modo headless')
    args = parser.parse_args()
    
    # Carregar dados do visitante
    visitor_data = load_visitor_data(args.visitor_data, args.visitor_id)
    
    print("🌐 HIKCENTRAL AUTOMATION - MODO AUTOMÁTICO")
    print("=" * 60)
    print("✅ Versão 100% automática baseada nos seletores capturados")
    if args.headless:
        print("✅ MODO HEADLESS - Execução sem interface visual")
    else:
        print("✅ MODO VISÍVEL - Com interface visual")
    print(f"✅ Visitante: {visitor_data['name']}")
    if visitor_data.get('photo_path'):
        print(f"📸 Foto: {visitor_data['photo_path']}")
    print("=" * 60)
    
    driver = None
    
    try:
        # Configurar Chrome
        print("\n🚀 Configurando Chrome...")
        chrome_options = Options()
        chrome_options.add_argument("--no-sandbox")
        chrome_options.add_argument("--disable-dev-shm-usage")
        chrome_options.add_argument("--disable-blink-features=AutomationControlled")
        
        if args.headless:
            chrome_options.add_argument("--headless")  # MODO HEADLESS
        
        chrome_options.add_argument("--window-size=1920,1080")
        chrome_options.add_experimental_option("excludeSwitches", ["enable-automation"])
        chrome_options.add_experimental_option('useAutomationExtension', False)
        
        # Criar driver
        service = Service(ChromeDriverManager().install())
        driver = webdriver.Chrome(service=service, options=chrome_options)
        driver.execute_script("Object.defineProperty(navigator, 'webdriver', {get: () => undefined})")
        
        print(f"📝 Testando com visitante: {visitor_data['name']}")
        print(f"🌐 Conectando ao HikCentral: http://45.4.132.189:3389/#/")
        
        # 1. LOGIN
        print("🔐 Fazendo login...")
        driver.get("http://45.4.132.189:3389/#/")
        time.sleep(3)
        
        username_field = driver.find_element("id", "username")
        password_field = driver.find_element("id", "password")
        
        # Preencher usuário
        username_field.clear()
        for char in "luca":
            username_field.send_keys(char)
            time.sleep(0.1)
        time.sleep(1)
        
        # Preencher senha
        password_field.clear()
        for char in "Luca123#":
            password_field.send_keys(char)
            time.sleep(0.1)
        time.sleep(1)
        
        # Clicar login
        login_btn = driver.find_element("css selector", ".login-btn")
        login_btn.click()
        print("✅ Login realizado!")
        
        # Aguardar carregamento
        print("⏳ Aguardando carregamento da página principal...")
        time.sleep(8)
        
        # 2. NAVEGAÇÃO
        print("🧭 Navegando para formulário...")
        
        # Procurar elemento Visitante
        visitante_elements = driver.find_elements("xpath", "//*[contains(text(), 'Visitante')]")
        if len(visitante_elements) >= 2:
            print(f"✅ Encontrados {len(visitante_elements)} elementos com 'Visitante'")
            visitante_elements[1].click()
            print("✅ Clicado em 'Visitante'")
            time.sleep(5)
        else:
            print("❌ Elemento 'Visitante' não encontrado")
            return False
        
        # Aguardar submenu carregar
        print("⏳ Aguardando submenu carregar...")
        time.sleep(5)
        
        # Clicar em "Entrada de visitante" na lista central
        print("🎯 Clicando em 'Entrada de visitante' na lista central...")
        entrada_central = driver.find_element("css selector", "div[title='Entrada de visitante'].guide-step-name")
        if entrada_central:
            entrada_central.click()
            print("✅ Clicado em 'Entrada de visitante' na lista central!")
            time.sleep(8)
        else:
            print("❌ 'Entrada de visitante' não encontrado na lista central")
            return False
        
        # SOLUÇÃO: CLICAR NOVAMENTE NO MENU "Entrada de visitante" DA SIDEBAR PARA REMOVER TOOLTIP
        print("🔧 Clicando novamente no menu 'Entrada de visitante' da sidebar para remover tooltip...")
        try:
            # Procurar pelo menu "Entrada de visitante" na sidebar
            menu_entrada = driver.find_element("css selector", "li[title='Entrada de visitante']")
            if menu_entrada:
                print("✅ Menu 'Entrada de visitante' encontrado na sidebar!")
                
                # Clicar NOVAMENTE para remover o tooltip
                menu_entrada.click()
                print("✅ Clicado novamente no menu para remover tooltip!")
                time.sleep(3)  # Aguardar tooltip desaparecer
                
            else:
                print("⚠️ Menu 'Entrada de visitante' não encontrado na sidebar")
        except Exception as e:
            print(f"⚠️ Erro ao clicar no menu: {e}")
        
        # Aguardar formulário carregar
        print("⏳ Aguardando formulário carregar...")
        time.sleep(8)
        
        # 3. CLICAR EM "ENTRADA DE VISITANTE NÃO RESERVADA" APÓS PASSAR DO TOOLTIP
        print("🎯 Clicando em 'Entrada de visitante não reservada'...")
        
        try:
            # Procurar pelo span específico
            span_nao_reservada = driver.find_element("xpath", "//span[text()='Entrada de visitante não reservada']")
            if span_nao_reservada:
                print("✅ Span 'Entrada de visitante não reservada' encontrado!")
                
                # Scroll para o span
                driver.execute_script("arguments[0].scrollIntoView(true);", span_nao_reservada)
                time.sleep(2)
                
                # ESTRATÉGIA 1: Tentar clicar normalmente
                try:
                    span_nao_reservada.click()
                    print("✅ Clicado no span 'Entrada de visitante não reservada'!")
                    time.sleep(5)  # Aguardar formulário abrir
                except Exception as e:
                    print(f"⚠️ Clique normal falhou: {e}")
                    
                    # ESTRATÉGIA 2: Clique com JavaScript
                    try:
                        driver.execute_script("arguments[0].click();", span_nao_reservada)
                        print("✅ Clicado no span com JavaScript!")
                        time.sleep(5)
                    except Exception as e2:
                        print(f"⚠️ Clique JavaScript falhou: {e2}")
                        
                        # ESTRATÉGIA 3: Clique acima do botão (parte não coberta pelo tooltip)
                        try:
                            print("🎯 Tentando clique acima do botão (parte não coberta pelo tooltip)...")
                            # Pegar posição do elemento
                            location = span_nao_reservada.location
                            size = span_nao_reservada.size
                            
                            # Calcular posição acima do botão
                            x = location['x'] + (size['width'] // 2)
                            y = location['y'] - 20  # 20px acima do botão
                            
                            # Clique com ActionChains na posição calculada
                            from selenium.webdriver.common.action_chains import ActionChains
                            actions = ActionChains(driver)
                            actions.move_by_offset(x, y).click().perform()
                            print("✅ Clicado acima do botão com ActionChains!")
                            time.sleep(5)
                            
                        except Exception as e3:
                            print(f"❌ Todas as estratégias falharam: {e3}")
                            return False
                
            else:
                print("❌ Span 'Entrada de visitante não reservada' não encontrado")
                return False
                
        except Exception as e:
            print(f"❌ Erro ao procurar span: {e}")
            return False
        
        # 4. FECHAR MESSAGE BOX CLICANDO EM "INSTALAR"
        print("🔧 Fechando message box clicando em 'Instalar'...")
        
        # Aguardar message box aparecer
        print("⏳ Aguardando message box aparecer (4 segundos)...")
        time.sleep(4)
        
        try:
            # Procurar pelo botão "Instalar"
            instalar_button = driver.find_element("xpath", "//button//span[text()=' Instalar ']")
            if instalar_button:
                print("✅ Botão 'Instalar' encontrado!")
                instalar_button.click()
                print("✅ Clicado em 'Instalar' - message box fechada!")
                time.sleep(3)  # Aguardar message box desaparecer
            else:
                print("⚠️ Botão 'Instalar' não encontrado")
        except Exception as e:
            print(f"⚠️ Erro ao clicar em 'Instalar': {e}")
        
        # Aguardar formulário carregar completamente
        print("⏳ Aguardando formulário carregar completamente...")
        time.sleep(5)
        
        # 5. PREENCHIMENTO AUTOMÁTICO
        print("⚡ PREENCHIMENTO AUTOMÁTICO...")
        
        # 5.1 NOME PRÓPRIO - CORRIGIDO: Usar primeiro input visível
        print("📝 Preenchendo nome próprio...")
        try:
            # Procurar pelo primeiro input visível e habilitado que não seja de pesquisa
            all_inputs = driver.find_elements("css selector", "input.el-input__inner")
            nome_field = None
            
            for inp in all_inputs:
                if inp.is_displayed() and inp.is_enabled():
                    placeholder = inp.get_attribute("placeholder") or ""
                    if "pesquisar" not in placeholder.lower():
                        nome_field = inp
                        print("✅ Primeiro campo (nome próprio) encontrado!")
                        break
            
            if nome_field:
                nome_field.clear()
                nome_field.send_keys(visitor_data['name'])
                print(f"✅ Nome próprio preenchido: {visitor_data['name']}")
                time.sleep(1)
            else:
                print("⚠️ Campo nome próprio não encontrado")
        except Exception as e:
            print(f"⚠️ Erro ao preencher nome próprio: {e}")
        
        # 5.2 APELIDO - CORRIGIDO: Usar segundo input visível
        print("📝 Preenchendo apelido...")
        try:
            # Procurar pelo segundo input visível e habilitado que não seja de pesquisa
            all_inputs = driver.find_elements("css selector", "input.el-input__inner")
            apelido_field = None
            valid_inputs = []
            
            for inp in all_inputs:
                if inp.is_displayed() and inp.is_enabled():
                    placeholder = inp.get_attribute("placeholder") or ""
                    if "pesquisar" not in placeholder.lower():
                        valid_inputs.append(inp)
            
            if len(valid_inputs) >= 2:
                apelido_field = valid_inputs[1]  # Segundo campo
                print("✅ Segundo campo (apelido) encontrado!")
                
                # Extrair sobrenome do nome completo
                name_parts = visitor_data['name'].split()
                sobrenome = name_parts[-1] if len(name_parts) > 1 else "Santos"
                
                apelido_field.clear()
                apelido_field.send_keys(sobrenome)
                print(f"✅ Apelido preenchido: {sobrenome}")
                time.sleep(1)
            else:
                print(f"⚠️ Encontrados apenas {len(valid_inputs)} campos válidos, esperado pelo menos 2")
        except Exception as e:
            print(f"⚠️ Erro ao preencher apelido: {e}")
        
        # 5.3 VISITADO
        print("📝 Preenchendo campo visitado...")
        try:
            visitado_field = driver.find_element("css selector", "input[placeholder='Pesquisar']")
            fill_field_with_tab(driver, visitado_field, "LUCCA LACERDA", "Visitado")
            
            # Clicar em "Pesquisar por nome da pessoa"
            try:
                pesquisar_option = driver.find_element("xpath", "//li[contains(@class, 'el-autocomplete-suggestion__item')]//label[text()='Pesquisar por nome da pessoa']")
                pesquisar_option.click()
                print("✅ Clicado em 'Pesquisar por nome da pessoa'!")
                time.sleep(2)
                
                # Clicar no nome da pessoa
                nome_pessoa = driver.find_element("xpath", "//div[contains(@class, 'ptl-title name-title') and @title='LUCCA LACERDA']")
                nome_pessoa.click()
                print("✅ Clicado no nome 'LUCCA LACERDA'!")
                time.sleep(2)
            except:
                print("⚠️ Opção de pesquisa não encontrada")
        except Exception as e:
            print(f"⚠️ Erro ao preencher visitado: {e}")
        
        # 5.4 OBJETIVO DA VISITA (AUTOMÁTICO)
        print("📝 Selecionando objetivo da visita...")
        try:
            objetivo_field = driver.find_element("css selector", "input[placeholder='Selecione um item.']")
            select_dropdown_option(driver, "input[placeholder='Selecione um item.']", "Fazer passeio e visita", "Objetivo da Visita")
        except Exception as e:
            print(f"⚠️ Erro ao selecionar objetivo: {e}")
        
        # 5.5 GRUPO DE VISITANTES (AUTOMÁTICO) - CORRIGIDO
        print("📝 Selecionando grupo de visitantes...")
        try:
            # Aguardar um pouco para objetivo ser processado
            time.sleep(3)
            
            # Procurar especificamente pelo segundo campo "Selecione um item." (grupo)
            grupo_inputs = driver.find_elements("css selector", "input[placeholder='Selecione um item.']")
            if len(grupo_inputs) >= 2:
                grupo_field = grupo_inputs[1]  # Segundo campo é o grupo
                print("✅ Campo grupo de visitantes encontrado (segundo campo)!")
                
                # Clicar para abrir dropdown
                grupo_field.click()
                print("✅ Campo grupo de visitantes clicado!")
                time.sleep(2)
                
                # Procurar pela opção "VisitanteS"
                try:
                    visitantes_option = driver.find_element("xpath", "//span[contains(text(), 'VisitanteS')]")
                    visitantes_option.click()
                    print("✅ Opção 'VisitanteS' selecionada!")
                    time.sleep(2)
                    
                    # Verificar se foi selecionado
                    field_value = grupo_field.get_attribute("value")
                    if "VisitanteS" in field_value:
                        print(f"✅ Grupo confirmado: {field_value}")
                    else:
                        print(f"⚠️ Grupo não foi atualizado: {field_value}")
                        
                except Exception as e:
                    print(f"⚠️ Erro ao clicar na opção VisitanteS: {e}")
                    
            else:
                print(f"⚠️ Encontrados apenas {len(grupo_inputs)} campos, esperado pelo menos 2")
                
        except Exception as e:
            print(f"⚠️ Erro ao selecionar grupo: {e}")
        
        # 5.6 GÊNERO - CORRIGIDO: Clicar no label "Masculino" diretamente
        print("📝 Selecionando gênero masculino...")
        try:
            # Estratégia 1: Clicar diretamente no label "Masculino"
            masculino_label = driver.find_element("xpath", "//span[contains(@class, 'el-radio__label') and text()='Masculino']")
            masculino_label.click()
            print("✅ Gênero masculino selecionado via label!")
            time.sleep(1)
            
        except Exception as e:
            print(f"⚠️ Erro ao clicar no label Masculino: {e}")
            
            # Estratégia 2: Clicar no input radio mesmo
            try:
                masculino_radio = driver.find_element("css selector", "input[type='radio'][value='1']")
                driver.execute_script("arguments[0].click();", masculino_radio)
                print("✅ Gênero masculino selecionado via JavaScript!")
                time.sleep(1)
            except Exception as e2:
                print(f"⚠️ Erro na estratégia JavaScript: {e2}")
                
                # Estratégia 3: Clicar no parent label
                try:
                    masculino_parent = driver.find_element("xpath", "//label[contains(@class, 'el-radio')]//span[text()='Masculino']/ancestor::label")
                    masculino_parent.click()
                    print("✅ Gênero masculino selecionado via parent label!")
                    time.sleep(1)
                except Exception as e3:
                    print(f"⚠️ Todas as estratégias de gênero falharam: {e3}")
        
        # 5.7 UPLOAD DE FOTO (ANTES DO TELEFONE)
        if visitor_data.get('photo_path'):
            print("📸 Fazendo upload da foto do visitante...")
            photo_success = upload_photo_to_hikcentral(driver, visitor_data['photo_path'])
            if photo_success:
                print("✅ Foto do visitante enviada com sucesso!")
            else:
                print("⚠️ Não foi possível enviar a foto")
        else:
            print("ℹ️ Nenhuma foto fornecida para upload")
        
        # 5.8 TELEFONE - CORRIGIDO: Campo com tips específico de telefone
        print("📝 Preenchendo telefone...")
        
        # Navegar para aba "Informação de acesso" se necessário
        try:
            info_acesso_tab = driver.find_element("xpath", "//div[contains(text(), 'Informação de acesso')]")
            info_acesso_tab.click()
            print("✅ Clicado em 'Informação de acesso'!")
            time.sleep(3)
        except Exception as e:
            print(f"⚠️ Erro ao clicar em 'Informação de acesso': {e}")
        
        # Procurar campo telefone pelo tips específico do HTML
        try:
            # Baseado no HTML: tips="1 a 32 caracteres permitidos, incluindo dígitos e sinais "+" e "-"."
            telefone_field = driver.find_element("css selector", "input[tips*='1 a 32 caracteres permitidos']")
            
            if telefone_field and telefone_field.is_displayed() and telefone_field.is_enabled():
                telefone_field.clear()
                telefone_field.send_keys(visitor_data['phone'])
                print(f"✅ Telefone preenchido: {visitor_data['phone']}")
                time.sleep(1)
            else:
                print("⚠️ Campo telefone encontrado mas não está visível/habilitado")
                
        except Exception as e:
            print(f"⚠️ Erro ao procurar campo telefone por tips: {e}")
            
            # Estratégia alternativa: procurar por maxlength="32" na aba atual
            try:
                telefone_field = driver.find_element("css selector", "input[maxlength='32'].el-input__inner")
                
                if telefone_field and telefone_field.is_displayed() and telefone_field.is_enabled():
                    telefone_field.clear()
                    telefone_field.send_keys(visitor_data['phone'])
                    print(f"✅ Telefone preenchido (via maxlength): {visitor_data['phone']}")
                    time.sleep(1)
                else:
                    print("⚠️ Campo telefone alternativo não disponível")
                    
            except Exception as e2:
                print(f"⚠️ Erro na estratégia alternativa do telefone: {e2}")
        
        # 5.9 RG - CORRIGIDO: Campo que aparece após expandir
        print("📝 Preenchendo RG (após expandir)...")
        try:
            # Baseado no HTML: tips="Intervalo: [0 a 128]" e maxlength="128"
            rg_field = driver.find_element("css selector", "input[tips*='Intervalo: [0 a 128]'][maxlength='128'].el-input__inner")
            
            if rg_field and rg_field.is_displayed() and rg_field.is_enabled():
                rg_field.clear()
                rg_field.send_keys(visitor_data['rg'])
                print(f"✅ RG preenchido: {visitor_data['rg']}")
                time.sleep(1)
            else:
                print("⚠️ Campo RG encontrado mas não está visível/habilitado")
                
        except Exception as e:
            print(f"⚠️ Erro ao preencher RG: {e}")
            
            # Estratégia alternativa: procurar por maxlength="128" (primeiro campo)
            try:
                rg_inputs = driver.find_elements("css selector", "input[maxlength='128'].el-input__inner")
                if rg_inputs and len(rg_inputs) >= 1:
                    rg_field = rg_inputs[0]  # Primeiro campo com maxlength="128"
                    if rg_field.is_displayed() and rg_field.is_enabled():
                        rg_field.clear()
                        rg_field.send_keys(visitor_data['rg'])
                        print(f"✅ RG preenchido (alternativo): {visitor_data['rg']}")
                        time.sleep(1)
                else:
                    print("⚠️ Campo RG alternativo não encontrado")
            except Exception as e2:
                print(f"⚠️ Erro na estratégia alternativa do RG: {e2}")
        
        # 5.10 PLACA VEÍCULO - CORRIGIDO: Campo abaixo do RG na imagem
        if visitor_data.get('placa'):
            print("📝 Preenchendo PLACA VEÍCULO (campo abaixo do RG)...")
            try:
                # Aguardar um pouco após preencher RG
                time.sleep(2)
                
                # Estratégia 1: Procurar especificamente pelo campo PLACA VEÍCULO
                try:
                    # Procurar por elemento que contenha o texto "PLACA VEÍCULO" e depois o input
                    placa_label = driver.find_element("xpath", "//*[contains(text(), 'PLACA VEÍCULO')]")
                    placa_field = placa_label.find_element("xpath", ".//following::input[@class='el-input__inner'][1]")
                    
                    if placa_field.is_displayed() and placa_field.is_enabled():
                        placa_field.clear()
                        placa_field.send_keys(visitor_data['placa'])
                        print(f"✅ PLACA VEÍCULO preenchida (via label): {visitor_data['placa']}")
                        time.sleep(1)
                    else:
                        raise Exception("Campo não visível/habilitado")
                        
                except Exception as e1:
                    print(f"⚠️ Estratégia 1 falhou: {e1}")
                    
                    # Estratégia 2: Pegar todos os campos maxlength="128" e usar o último
                    try:
                        all_128_inputs = driver.find_elements("css selector", "input[maxlength='128'].el-input__inner")
                        visible_128_inputs = [inp for inp in all_128_inputs if inp.is_displayed() and inp.is_enabled()]
                        
                        if len(visible_128_inputs) >= 2:
                            placa_field = visible_128_inputs[-1]  # Último campo visível
                            
                            # Scroll para garantir que o campo está visível
                            driver.execute_script("arguments[0].scrollIntoView(true);", placa_field)
                            time.sleep(1)
                            
                            placa_field.clear()
                            placa_field.send_keys(visitor_data['placa'])
                            print(f"✅ PLACA VEÍCULO preenchida (último campo): {visitor_data['placa']}")
                            time.sleep(1)
                        else:
                            raise Exception(f"Apenas {len(visible_128_inputs)} campos visíveis encontrados")
                            
                    except Exception as e2:
                        print(f"⚠️ Estratégia 2 falhou: {e2}")
                        
                        # Estratégia 3: Procurar por posição relativa ao RG
                        try:
                            # Encontrar o campo RG primeiro
                            rg_label = driver.find_element("xpath", "//*[contains(text(), 'RG')]")
                            # Procurar o próximo input após o RG
                            placa_field = rg_label.find_element("xpath", ".//following::input[@class='el-input__inner'][2]")
                            
                            if placa_field.is_displayed() and placa_field.is_enabled():
                                driver.execute_script("arguments[0].scrollIntoView(true);", placa_field)
                                time.sleep(1)
                                placa_field.clear()
                                placa_field.send_keys(visitor_data['placa'])
                                print(f"✅ PLACA VEÍCULO preenchida (relativo ao RG): {visitor_data['placa']}")
                                time.sleep(1)
                            else:
                                raise Exception("Campo não visível/habilitado")
                                
                        except Exception as e3:
                            print(f"⚠️ Todas as estratégias da PLACA falharam: {e3}")
                    
            except Exception as e:
                print(f"⚠️ Erro geral ao preencher PLACA VEÍCULO: {e}")
        
        print("\n🎉 FORMULÁRIO PREENCHIDO 100% AUTOMATICAMENTE!")
        print("✅ Todos os campos foram preenchidos")
        print(f"✅ Nome: {visitor_data['name']}")
        print("✅ Objetivo da visita: Fazer passeio e visita")
        print("✅ Grupo de visitantes: VisitanteS")
        print(f"✅ Telefone: {visitor_data['phone']}")
        print(f"✅ RG: {visitor_data['rg']}")
        if visitor_data.get('placa'):
            print(f"✅ Placa: {visitor_data['placa']}")
        if visitor_data.get('photo_path'):
            print(f"📸 Foto: Enviada")
        
        # CLICAR EM "ENTRADA" PARA CONFIRMAR O CADASTRO
        print("\n🎯 Clicando em 'Entrada' para confirmar o cadastro...")
        try:
            # Procurar pelo botão "Entrada"
            entrada_button = driver.find_element("xpath", "//button//span[text()='Entrada']")
            
            if entrada_button and entrada_button.is_displayed():
                # Scroll para garantir que o botão está visível
                driver.execute_script("arguments[0].scrollIntoView(true);", entrada_button)
                time.sleep(1)
                
                entrada_button.click()
                print("✅ Clicado em 'Entrada' - Cadastro confirmado!")
                time.sleep(5)  # Aguardar processamento
                
                print("🎉 VISITANTE CADASTRADO COM SUCESSO!")
                
            else:
                print("⚠️ Botão 'Entrada' não encontrado ou não visível")
                
        except Exception as e:
            print(f"⚠️ Erro ao clicar em 'Entrada': {e}")
            
            # Estratégia alternativa: procurar por qualquer botão com "Entrada"
            try:
                entrada_alt = driver.find_element("xpath", "//button[contains(text(), 'Entrada')]")
                entrada_alt.click()
                print("✅ Clicado em 'Entrada' (estratégia alternativa)!")
                time.sleep(5)
                print("🎉 VISITANTE CADASTRADO COM SUCESSO!")
            except Exception as e2:
                print(f"⚠️ Erro na estratégia alternativa: {e2}")
                print("💡 Clique manualmente no botão 'Entrada' para confirmar")
        
        # Aguardar análise do resultado
        if not args.headless:
            print("\n⏳ AGUARDANDO 15 SEGUNDOS para verificar resultado...")
            print("💡 Verifique se o cadastro foi processado com sucesso!")
            time.sleep(15)
        
        print("✅ Teste concluído!")
        return True
        
    except Exception as e:
        print(f"❌ Erro crítico: {e}")
        import traceback
        traceback.print_exc()
        return False
        
    finally:
        if not args.headless:
            # Aguardar input do usuário apenas em modo visível
            input("\n⏳ Pressione ENTER para fechar o Chrome...")
        
        try:
            if driver:
                print("🔒 Fechando driver...")
                driver.quit()
        except:
            pass

    print("\n🏁 Teste concluído!")
    return True

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
